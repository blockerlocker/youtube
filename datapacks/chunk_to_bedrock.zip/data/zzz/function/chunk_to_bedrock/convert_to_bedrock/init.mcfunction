data modify storage mining_deletes_chunks:temp all.success set value true

summon marker ~ ~ ~ {Tags:[chunk_coord]}

execute store result storage mining_deletes_chunks:temp all.x int 16 run data get entity @n[type=marker,tag=chunk_coord] Pos[0] 0.0625
execute store result storage mining_deletes_chunks:temp all.z int 16 run data get entity @n[type=marker,tag=chunk_coord] Pos[2] 0.0625

kill @n[type=marker,tag=chunk_coord]

function zzz:chunk_to_bedrock/convert_to_bedrock/commit with storage mining_deletes_chunks:temp all