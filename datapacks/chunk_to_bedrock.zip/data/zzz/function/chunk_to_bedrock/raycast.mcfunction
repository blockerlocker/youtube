function iris:get_target

execute at @n[tag=iris.targeted_block] run function zzz:chunk_to_bedrock/convert_to_bedrock/init