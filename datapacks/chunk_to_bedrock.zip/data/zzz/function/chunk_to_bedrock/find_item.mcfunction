execute as @e[type=item,distance=..1,nbt={Age:0s,PickupDelay:10s}] at @s run return run function zzz:chunk_to_bedrock/convert_to_bedrock/init

execute positioned ^ ^ ^0.1 unless entity @s[distance=8..] run return run function zzz:chunk_to_bedrock/find_item