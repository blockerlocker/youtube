execute if predicate bldp:mined_block run function zzz:bldp/mined_block/reset


function zzz:chunk_to_bedrock/find_item

execute unless data storage mining_deletes_chunks:temp all.success run function zzz:chunk_to_bedrock/raycast

execute unless data storage mining_deletes_chunks:temp all.success positioned ^ ^ ^5 run function zzz:chunk_to_bedrock/convert_to_bedrock/init


data remove storage mining_deletes_chunks:temp all