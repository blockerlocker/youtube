execute as @a if data entity @s {XpP:0.0f,XpLevel:0} unless data entity @s attributes[{id:"minecraft:block_break_speed",modifiers:[{id:"mining_costs_xp:no_xp"}]}] at @s run function mining_costs_xp:zzz/no_xp_warning
execute as @a run attribute @s block_break_speed modifier remove mining_costs_xp:no_xp
execute as @a if data entity @s {XpP:0.0f,XpLevel:0} run attribute @s minecraft:block_break_speed modifier add mining_costs_xp:no_xp -100 add_multiplied_total

execute as @a run function mining_costs_xp:zzz/player_score_check