xp add @s -1 points

function mining_costs_xp:zzz/reset