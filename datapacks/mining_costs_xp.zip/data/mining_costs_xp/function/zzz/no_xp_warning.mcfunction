title @s actionbar {text:"You are out of XP",color:yellow,underlined:true}
playsound block.glass.break ui @s