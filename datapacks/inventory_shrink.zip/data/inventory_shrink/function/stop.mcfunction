scoreboard players set @a inventory_shrink 36
data modify storage inventory_shrink:state all.active set value false
clear @s *[custom_data~{slot_lock:true}]