advancement revoke @s only inventory_shrink:inventory_changed

execute anchored eyes run loot spawn ^ ^-0.5 ^0.5 loot inventory_shrink:drop

loot replace entity @s container.0 loot inventory_shrink:shrink