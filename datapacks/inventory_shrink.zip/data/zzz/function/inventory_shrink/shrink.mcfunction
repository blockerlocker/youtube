scoreboard players remove @s inventory_shrink 1

playsound minecraft:entity.item.break ui @s ~ ~ ~ 0.5 1.2

execute anchored eyes run particle minecraft:item{item:{id:smooth_stone}} ^ ^-0.4 ^0.6 0 0 0 0.25 20

function zzz:inventory_shrink/modify_inventory