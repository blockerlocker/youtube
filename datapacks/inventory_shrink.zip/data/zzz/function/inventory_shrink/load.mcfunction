scoreboard objectives add inventory_shrink dummy
advancement revoke @a only inventory_shrink:inventory_changed

execute unless data storage inventory_shrink:settings period run data modify storage inventory_shrink:settings period set value 1200