item modify entity @s player.cursor {function:filtered,item_filter:{predicates:{custom_data:{slot_lock:true}}},on_pass:{function:set_count,count:0}}
item modify entity @s player.crafting.0 {function:filtered,item_filter:{predicates:{custom_data:{slot_lock:true}}},on_pass:{function:set_count,count:0}}
item modify entity @s player.crafting.1 {function:filtered,item_filter:{predicates:{custom_data:{slot_lock:true}}},on_pass:{function:set_count,count:0}}
item modify entity @s player.crafting.2 {function:filtered,item_filter:{predicates:{custom_data:{slot_lock:true}}},on_pass:{function:set_count,count:0}}
item modify entity @s player.crafting.3 {function:filtered,item_filter:{predicates:{custom_data:{slot_lock:true}}},on_pass:{function:set_count,count:0}}
item modify entity @s weapon.offhand {function:filtered,item_filter:{predicates:{custom_data:{slot_lock:true}}},on_pass:{function:set_count,count:0}}