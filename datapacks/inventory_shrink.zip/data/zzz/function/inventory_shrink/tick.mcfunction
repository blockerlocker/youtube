function zzz:inventory_shrink/periodic_tick with storage inventory_shrink:settings

execute if data storage inventory_shrink:state all{active:true} as @a run function zzz:inventory_shrink/player_tick

execute as @e[type=item] if items entity @s contents *[custom_data~{slot_lock:true}] run kill @s

execute as @a[scores={inventory_shrink=..35}] unless items entity @s container.9 *[custom_data~{slot_lock:true}] run function zzz:inventory_shrink/modify_inventory