execute as @e[tag=minejump_destroy_animation,distance=..0.1] run data modify entity @s text.sprite set from entity @n[tag=minejump_destroy_animation_root] data.frames[0]
data remove entity @s data.frames[0]
scoreboard players set @e[tag=minejump_destroy_animation,distance=..0.1] minejump 0

$particle block{block_state:{Name:"$(Name)"}} ~ ~0.5 ~ 0.25 0.1 0.25 0 20
$playsound minecraft:block.$(name_simple).hit block @a ~ ~ ~ 1 0.5
playsound minecraft:block.stone.hit block @a ~ ~ ~ 0.5 0.5

execute unless data entity @s data.frames[0] run setblock ~ ~ ~ air destroy
execute unless data entity @s data.frames[0] run kill @e[tag=minejump_destroy_animation,distance=..0.1]