execute positioned ~0.3 ~-0.01 ~0.3 align xyz positioned ~0.5 ~0.5 ~0.5 unless entity @n[type=marker,tag=minejump_landing_check,distance=..0.1] run summon marker ~ ~ ~ {Tags:[minejump_landing_check]}
execute positioned ~0.3 ~-0.01 ~-0.3 align xyz positioned ~0.5 ~0.5 ~0.5 unless entity @n[type=marker,tag=minejump_landing_check,distance=..0.1] run summon marker ~ ~ ~ {Tags:[minejump_landing_check]}
execute positioned ~-0.3 ~-0.01 ~0.3 align xyz positioned ~0.5 ~0.5 ~0.5 unless entity @n[type=marker,tag=minejump_landing_check,distance=..0.1] run summon marker ~ ~ ~ {Tags:[minejump_landing_check]}
execute positioned ~-0.3 ~-0.01 ~-0.3 align xyz positioned ~0.5 ~0.5 ~0.5 unless entity @n[type=marker,tag=minejump_landing_check,distance=..0.1] run summon marker ~ ~ ~ {Tags:[minejump_landing_check]}

execute as @e[type=marker,tag=minejump_landing_check] at @s run function zzz:minejump/mine/init

kill @e[type=marker,tag=minejump_landing_check]

scoreboard players remove @s minejump_strength_last 1
execute if score @s minejump_strength_last matches 1.. run function zzz:minejump/loop