execute as @a run function zzz:minejump/player_tick

execute as @a[scores={minejump_strength_last=1..}] if predicate {condition:entity_properties,entity:this,predicate:{flags:{is_on_ground:1b}}} at @s run function zzz:minejump/landed

scoreboard players add @e[type=text_display,tag=minejump_destroy_animation] minejump 1
kill @e[type=text_display,tag=minejump_destroy_animation,scores={minejump=100..}]

effect give @a mining_fatigue infinite 255 true