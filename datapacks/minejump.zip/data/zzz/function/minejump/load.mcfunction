scoreboard objectives add minejump dummy
scoreboard objectives add minejump_strength dummy
scoreboard objectives add minejump_strength_last dummy