scoreboard players operation @s minejump_strength_last = @s minejump_strength
execute store result score @s minejump_strength run data get entity @s fall_distance