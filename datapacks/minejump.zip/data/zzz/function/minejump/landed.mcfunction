scoreboard players set @s minejump 0
scoreboard players add @s minejump_strength_last 1
function zzz:minejump/loop