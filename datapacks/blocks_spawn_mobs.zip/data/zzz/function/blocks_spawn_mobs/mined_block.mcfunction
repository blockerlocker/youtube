function zzz:bldp/mined_block/reset

function zzz:bldp/func/random/mob

execute at @n[type=marker,tag=iris.targeted_block] run function zzz:blocks_spawn_mobs/summon_mob with storage bldp:array_random