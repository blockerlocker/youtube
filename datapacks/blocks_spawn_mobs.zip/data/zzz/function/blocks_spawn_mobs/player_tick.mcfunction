execute if predicate bldp:mined_block run function zzz:blocks_spawn_mobs/mined_block

function iris:get_target