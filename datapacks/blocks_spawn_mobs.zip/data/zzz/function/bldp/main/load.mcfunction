scoreboard objectives add operator dummy

execute unless data storage bldp:registry all.blocks run function zzz:bldp/registry/blocks
execute unless data storage bldp:registry all.mobs run function zzz:bldp/registry/mobs