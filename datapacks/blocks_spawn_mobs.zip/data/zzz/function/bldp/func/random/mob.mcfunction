data modify storage bldp:array_random in set from storage bldp:registry all.mobs
function zzz:bldp/func/array/random/init