summon tnt ~ ~ ~ {fuse:0}
damage @s 999999999999999 minecraft:explosion by @n[type=tnt]
function dont_mine_twice:zzz/reset