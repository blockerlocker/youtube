playsound minecraft:entity.player.teleport player @a ~ ~ ~ 0.25 1

tp @s ~ ~ ~