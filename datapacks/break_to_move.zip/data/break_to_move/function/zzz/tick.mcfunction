execute as @a if predicate break_to_move:broke_any run function break_to_move:zzz/teleport_to_block

execute as @a if predicate {condition:"minecraft:entity_properties",entity:"this",predicate:{vehicle:{}}} run ride @s dismount

execute as @a run attribute @s movement_speed base set -1
execute as @a run attribute @s jump_strength base set -1