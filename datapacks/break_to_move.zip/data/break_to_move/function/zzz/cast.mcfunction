execute at @n[type=item,distance=..1,nbt={Age:0s}] align xyz positioned ~0.5 ~ ~0.5 run return run function break_to_move:zzz/teleport

execute positioned ^ ^ ^0.25 run function break_to_move:zzz/cast