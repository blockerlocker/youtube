function break_to_move:zzz/reset_scores

execute at @s anchored eyes positioned ^ ^ ^ run function break_to_move:zzz/cast