gamerule max_block_modifications 110976

execute unless data storage chunk_to_block:settings all.block run data modify storage chunk_to_block:settings all.block set value bedrock