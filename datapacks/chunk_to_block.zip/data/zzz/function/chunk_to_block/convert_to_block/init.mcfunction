data modify storage chunk_to_block:temp all.success set value true

summon marker ~ ~ ~ {Tags:[chunk_coord]}

execute store result storage chunk_to_block:temp all.x int 16 run data get entity @n[type=marker,tag=chunk_coord] Pos[0] 0.0625
execute store result storage chunk_to_block:temp all.z int 16 run data get entity @n[type=marker,tag=chunk_coord] Pos[2] 0.0625

kill @n[type=marker,tag=chunk_coord]

data modify storage chunk_to_block:temp all.block set from storage chunk_to_block:settings all.block

execute if data storage chunk_to_block:settings all{block:"random"} run function zzz:bldp/random_block/get
execute if data storage chunk_to_block:settings all{block:"random"} run data modify storage chunk_to_block:temp all.block set from storage bldp:random_block out

function zzz:chunk_to_block/convert_to_block/commit with storage chunk_to_block:temp all