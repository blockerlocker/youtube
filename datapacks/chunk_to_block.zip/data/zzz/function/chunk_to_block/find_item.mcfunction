execute as @e[type=item,distance=..1,nbt={Age:0s,PickupDelay:10s}] at @s run return run function zzz:chunk_to_block/convert_to_block/init

execute positioned ^ ^ ^0.1 unless entity @s[distance=8..] run return run function zzz:chunk_to_block/find_item