execute if predicate bldp:mined_block run function zzz:bldp/mined_block/reset


function zzz:chunk_to_block/find_item

execute unless data storage chunk_to_block:temp all.success run function zzz:chunk_to_block/raycast

execute unless data storage chunk_to_block:temp all.success positioned ^ ^ ^5 run function zzz:chunk_to_block/convert_to_block/init


data remove storage chunk_to_block:temp all