function iris:get_target

execute at @n[tag=iris.targeted_block] run function zzz:chunk_to_block/convert_to_block/init