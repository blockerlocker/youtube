data remove storage bldp:random_block out

execute store result score #bldp_random_block operator if data storage bldp:random_block all[]
execute store result storage bldp:temp all.random.value int 1 run scoreboard players remove #bldp_random_block operator 1
function zzz:bldp/func/random_value with storage bldp:temp all.random

function zzz:bldp/random_block/commit with storage bldp:temp all.random

data remove storage bldp:temp all
