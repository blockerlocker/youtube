tag @s add player_magnet

execute if predicate {condition:entity_properties,entity:this,predicate:{"type_specific/player":{input:{sprint:true}}}} as @e[type=#player_magnet:magnetizable,distance=..64] at @s facing entity @p[tag=player_magnet] feet run function zzz:player_magnet/attract
execute if predicate {condition:entity_properties,entity:this,predicate:{"type_specific/player":{input:{sneak:true}}}} as @e[type=#player_magnet:magnetizable,distance=..64] at @s facing entity @p[tag=player_magnet] feet run function zzz:player_magnet/repel

execute if predicate {condition:entity_properties,entity:this,predicate:{"type_specific/player":{input:{sprint:true}}}} run particle minecraft:trial_spawner_detection ~ ~ ~ 0.25 0.25 0.25 0 1
execute if predicate {condition:entity_properties,entity:this,predicate:{"type_specific/player":{input:{sneak:true}}}} run particle minecraft:trial_spawner_detection_ominous ~ ~ ~ 0.25 0.25 0.25 0 1

tag @s remove player_magnet