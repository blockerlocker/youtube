execute if predicate {condition:random_chance,chance:0.1} run particle minecraft:trial_spawner_detection_ominous ~ ~ ~ 0.25 0.25 0.25 0 1

execute store result score #player_magnet_mob_x operator run data get entity @s Motion[0] 1000
execute store result score #player_magnet_mob_y operator run data get entity @s Motion[1] 1000
execute store result score #player_magnet_mob_z operator run data get entity @s Motion[2] 1000

execute positioned 0.0 0.0 0.0 positioned ^ ^ ^-0.1 summon marker run function zzz:player_magnet/get_vector

execute store result entity @s Motion[0] double 0.001 run scoreboard players operation #player_magnet_mob_x operator += #player_magnet_vector_x operator
execute store result entity @s Motion[1] double 0.001 run scoreboard players operation #player_magnet_mob_y operator += #player_magnet_vector_y operator
execute store result entity @s Motion[2] double 0.001 run scoreboard players operation #player_magnet_mob_z operator += #player_magnet_vector_z operator

data remove storage player_magnet:temp all

attribute @s step_height modifier add player_magnet 0.5 add_value