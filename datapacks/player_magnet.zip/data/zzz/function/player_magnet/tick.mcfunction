execute as @e[type=#player_magnet:magnetizable] run attribute @s step_height modifier remove player_magnet

execute as @a at @s run function zzz:player_magnet/player