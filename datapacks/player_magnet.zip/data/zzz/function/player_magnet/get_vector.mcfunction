execute store result score #player_magnet_vector_x operator run data get entity @s Pos[0] 1000
execute store result score #player_magnet_vector_y operator run data get entity @s Pos[1] 1000
execute store result score #player_magnet_vector_z operator run data get entity @s Pos[2] 1000

kill @s