function zzz:world_shrink/check_loaded_area

execute store result storage world_shrink:temp all.radius int 1 run scoreboard players get @s world_shrink
execute store result storage world_shrink:temp all.buffer_radius int 1 run scoreboard players remove @s world_shrink 2
execute store result storage world_shrink:temp all.step int 1 run scoreboard players get #step world_shrink

function zzz:world_shrink/chunk_edge_tick with storage world_shrink:temp all

data remove storage world_shrink:temp all