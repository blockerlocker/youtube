execute as @a at @s run function zzz:world_shrink/player_shrink_tick

execute if score #step world_shrink matches ..-64 run function world_shrink:stop

scoreboard players remove #step world_shrink 1