scoreboard players set @s world_shrink 16

execute if loaded ~ ~ ~32 run scoreboard players set @s world_shrink 32

execute if loaded ~ ~ ~64 run scoreboard players set @s world_shrink 64