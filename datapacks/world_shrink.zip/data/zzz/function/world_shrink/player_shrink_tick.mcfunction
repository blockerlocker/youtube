execute store result storage world_shrink:temp all.radius int 1 run scoreboard players get @s world_shrink
execute store result storage world_shrink:temp all.step int 1 run scoreboard players get #step world_shrink

function zzz:world_shrink/player_shrink with storage world_shrink:temp all

data remove storage world_shrink:temp all