execute if data storage world_shrink:state all{active:true} run title @a actionbar [{text:"World Height: "},{score:{name:"#step",objective:world_shrink}}]

execute if data storage world_shrink:state all{active:true} as @a at @s run function zzz:world_shrink/player_tick

execute if predicate {condition:"minecraft:time_check",clock:"overworld",value:0,period:20} if data storage world_shrink:state all{active:true} run function zzz:world_shrink/shrink_tick