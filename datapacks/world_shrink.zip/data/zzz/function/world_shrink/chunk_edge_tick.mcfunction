$fill ~$(radius) $(step) ~$(radius) ~$(buffer_radius) 319 ~-$(buffer_radius) air strict
$fill ~$(radius) $(step) ~$(radius) ~-$(buffer_radius) 319 ~$(buffer_radius) air strict
$fill ~-$(radius) $(step) ~-$(radius) ~$(buffer_radius) 319 ~-$(buffer_radius) air strict
$fill ~-$(radius) $(step) ~-$(radius) ~-$(buffer_radius) 319 ~$(buffer_radius) air strict