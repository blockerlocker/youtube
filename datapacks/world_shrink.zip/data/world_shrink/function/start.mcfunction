scoreboard players set #step world_shrink 319
data modify storage world_shrink:state all.active set value true