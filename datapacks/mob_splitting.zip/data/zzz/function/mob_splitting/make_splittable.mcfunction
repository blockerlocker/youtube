# Tag mob to confirm it's initialized and avoid running this setup function twice
tag @s add mob_splitting


# Do not setup mob for splitting if it's at the smallest scale
execute if data entity @s attributes[{id:"minecraft:scale",base:0.55d}] run return fail


# Add setup tag for targetting
tag @s add mob_splitting_setup


# Get mob id
summon text_display ~ ~ ~ {text:{selector:"@n[type=#mob_splitting:splittable,tag=mob_splitting_setup]"},Tags:[mob_splitting_text_display]}
data modify storage mob_splitting:temp all.id set from entity @n[type=text_display,tag=mob_splitting_text_display,distance=..1] text.hover_event.id
kill @e[type=text_display,tag=mob_splitting_text_display]


# Set split mob's scale
data modify storage mob_splitting:temp all.data.attributes[{id:scale}].base set value 0.85
execute if data entity @s attributes[{id:"minecraft:scale",base:0.85d}] run data modify storage mob_splitting:temp all.data.attributes[{id:scale}].base set value 0.7
execute if data entity @s attributes[{id:"minecraft:scale",base:0.7d}] run data modify storage mob_splitting:temp all.data.attributes[{id:scale}].base set value 0.55


# Get extra mob data
execute if data entity @s variant run data modify storage mob_splitting:temp all.data.variant set from entity @s variant
execute if data entity @s Variant run data modify storage mob_splitting:temp all.data.Variant set from entity @s Variant
execute if data entity @s RabbitType run data modify storage mob_splitting:temp all.data.RabbitType set from entity @s RabbitType
execute if data entity @s Type run data modify storage mob_splitting:temp all.data.Type set from entity @s Type
execute if data entity @s VillagerData run data modify storage mob_splitting:temp all.data.VillagerData set from entity @s VillagerData


# Store mob id and data on droppable item
execute if entity @s[type=#mob_splitting:no_body_slot] run item replace entity @s armor.body with cod[custom_data={mob_splitting:{}},!item_model,equippable={slot:body,equip_sound:intentionally_empty}]
execute if entity @s[type=#mob_splitting:no_body_slot] run data modify entity @s equipment.body.components."minecraft:custom_data".mob_splitting set from storage mob_splitting:temp all
execute if entity @s[type=#mob_splitting:no_body_slot] run data modify entity @s drop_chances.body set value 2

execute if entity @s[type=#mob_splitting:no_chest_slot] run item replace entity @s armor.chest with cod[custom_data={mob_splitting:{}},!item_model,equippable={slot:chest,equip_sound:intentionally_empty}]
execute if entity @s[type=#mob_splitting:no_chest_slot] run data modify entity @s equipment.chest.components."minecraft:custom_data".mob_splitting set from storage mob_splitting:temp all
execute if entity @s[type=#mob_splitting:no_chest_slot] run data modify entity @s drop_chances.chest set value 2


# Creeper explosion special case
execute if entity @s[type=creeper] run summon marker ~ ~ ~ {Tags:[mob_splitting_explosion_marker,mob_splitting_temp]}
data modify entity @n[type=marker,tag=mob_splitting_explosion_marker,tag=mob_splitting_temp] data.mob_splitting set from storage mob_splitting:temp all 
execute if entity @s[type=creeper] run ride @n[type=marker,tag=mob_splitting_explosion_marker,tag=mob_splitting_temp] mount @s
tag @n[type=marker,tag=mob_splitting_explosion_marker,tag=mob_splitting_temp] remove mob_splitting_temp


# Cleanup
data remove storage mob_splitting:temp all
tag @s remove mob_splitting_setup