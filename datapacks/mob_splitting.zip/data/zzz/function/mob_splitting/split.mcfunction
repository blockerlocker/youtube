$summon $(id) ^0.25 ^ ^ $(data)
$summon $(id) ^-0.25 ^ ^  $(data)
kill @s