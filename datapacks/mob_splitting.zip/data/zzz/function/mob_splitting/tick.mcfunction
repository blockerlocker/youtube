# Setup mobs for splitting
execute at @a as @e[type=#mob_splitting:splittable,tag=!mob_splitting,distance=..64] at @s run function zzz:mob_splitting/make_splittable


# Detect dropped item used for mob splitting
execute as @e[type=item] if items entity @s contents cod[custom_data~{mob_splitting:{}}] at @s run function zzz:mob_splitting/split with entity @s Item.components."minecraft:custom_data".mob_splitting


# Detect exploded creeper for mob splitting
execute as @e[type=marker,tag=mob_splitting_explosion_marker] if predicate {condition:entity_properties,entity:this,predicate:{vehicle:{nbt:"{Health:0.0f}"}}} run kill @s
execute as @e[type=marker,tag=mob_splitting_explosion_marker] unless predicate {condition:entity_properties,entity:this,predicate:{vehicle:{}}} at @s unless entity @p[distance=..32] run kill @s
execute as @e[type=marker,tag=mob_splitting_explosion_marker] unless predicate {condition:entity_properties,entity:this,predicate:{vehicle:{}}} at @s run function zzz:mob_splitting/split with entity @s data.mob_splitting
