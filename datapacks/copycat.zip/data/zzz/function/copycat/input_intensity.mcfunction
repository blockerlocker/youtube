execute positioned 0.0 0.0 0.0 positioned ^ ^ ^0.225 run function zzz:copycat/get_motion_vector

execute as @e[type=!player,nbt={Brain:{}},distance=..128] run function zzz:copycat/apply_motion

data remove storage copycat:temp motion