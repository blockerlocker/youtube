attribute @s step_height modifier add copycat:step 0.5 add_value
rotate @s ~ ~
data modify entity @s Motion[0] set from storage copycat:temp motion[0]
data modify entity @s Motion[2] set from storage copycat:temp motion[2]