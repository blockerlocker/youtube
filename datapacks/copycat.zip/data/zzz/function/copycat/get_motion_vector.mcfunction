execute store success storage copycat:temp loaded.a int 1 run forceload query 1 1
execute store success storage copycat:temp loaded.b int 1 run forceload query 1 -1
execute store success storage copycat:temp loaded.c int 1 run forceload query -1 1
execute store success storage copycat:temp loaded.d int 1 run forceload query -1 -1
execute if data storage copycat:temp loaded{a:0} run forceload add 1 1 1 1
execute if data storage copycat:temp loaded{b:0} run forceload add 1 -1 1 -1
execute if data storage copycat:temp loaded{c:0} run forceload add -1 1 -1 1
execute if data storage copycat:temp loaded{d:0} run forceload add -1 -1 -1 -1

execute run summon marker ~ ~ ~ {Tags:[copycat_motion]}
execute run data modify storage copycat:temp motion set from entity @n[type=marker,tag=copycat_motion] Pos
kill @e[type=marker,tag=copycat_motion]

execute if data storage copycat:temp loaded{a:0} run forceload remove 1 1 1 1
execute if data storage copycat:temp loaded{b:0} run forceload remove 1 -1 1 -1
execute if data storage copycat:temp loaded{c:0} run forceload remove -1 1 -1 1
execute if data storage copycat:temp loaded{d:0} run forceload remove -1 -1 -1 -1
data remove storage copycat:temp loaded