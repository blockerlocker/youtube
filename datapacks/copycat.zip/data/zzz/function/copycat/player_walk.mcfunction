# Single Input
execute if predicate {condition:entity_properties,entity:this,predicate:{type_specific:{type:player,input:{forward:true,backward:false,left:false,right:false}}}} rotated ~ 0 run return run function zzz:copycat/input_intensity
execute if predicate {condition:entity_properties,entity:this,predicate:{type_specific:{type:player,input:{forward:false,backward:true,left:false,right:false}}}} rotated ~180 0 run return run function zzz:copycat/input_intensity
execute if predicate {condition:entity_properties,entity:this,predicate:{type_specific:{type:player,input:{forward:false,backward:false,left:true,right:false}}}} rotated ~-90 0 run return run function zzz:copycat/input_intensity
execute if predicate {condition:entity_properties,entity:this,predicate:{type_specific:{type:player,input:{forward:false,backward:false,left:false,right:true}}}} rotated ~90 0 run return run function zzz:copycat/input_intensity

# Dual Input
execute if predicate {condition:entity_properties,entity:this,predicate:{type_specific:{type:player,input:{forward:true,backward:false,left:true,right:false}}}} rotated ~-45 0 run return run function zzz:copycat/input_intensity
execute if predicate {condition:entity_properties,entity:this,predicate:{type_specific:{type:player,input:{forward:true,backward:false,left:false,right:true}}}} rotated ~45 0 run return run function zzz:copycat/input_intensity
execute if predicate {condition:entity_properties,entity:this,predicate:{type_specific:{type:player,input:{forward:false,backward:true,left:true,right:false}}}} rotated ~-135 0 run return run function zzz:copycat/input_intensity
execute if predicate {condition:entity_properties,entity:this,predicate:{type_specific:{type:player,input:{forward:false,backward:true,left:false,right:true}}}} rotated ~135 0 run return run function zzz:copycat/input_intensity

# Triple Input
execute if predicate {condition:entity_properties,entity:this,predicate:{type_specific:{type:player,input:{forward:true,backward:true,left:true,right:false}}}} rotated ~-90 0 run return run function zzz:copycat/input_intensity
execute if predicate {condition:entity_properties,entity:this,predicate:{type_specific:{type:player,input:{forward:true,backward:true,left:false,right:true}}}} rotated ~90 0 run return run function zzz:copycat/input_intensity
execute if predicate {condition:entity_properties,entity:this,predicate:{type_specific:{type:player,input:{forward:true,backward:false,left:true,right:true}}}} rotated ~ 0 run return run function zzz:copycat/input_intensity
execute if predicate {condition:entity_properties,entity:this,predicate:{type_specific:{type:player,input:{forward:false,backward:true,left:true,right:true}}}} rotated ~180 0 run return run function zzz:copycat/input_intensity