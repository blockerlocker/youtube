execute unless block ~ ~ ~ #mineable/pickaxe run loot spawn ~ ~ ~ mine ~ ~ ~ air
swing

summon item_display ~ ~ ~ {Tags:[copycat_blockstate]}
loot replace entity @n[type=item_display,tag=copycat_blockstate] contents loot blockstate:get
function zzz:copycat/mine/particle with entity @n[type=item_display,tag=copycat_blockstate] item.components."minecraft:custom_data"
kill @n[type=item_display,tag=copycat_blockstate]

setblock ~ ~ ~ air replace
