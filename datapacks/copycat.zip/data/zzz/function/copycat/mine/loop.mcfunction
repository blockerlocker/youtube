execute unless block ~ ~ ~ #copycat:fluid run return run execute unless block ~ ~ ~ #copycat:unbreakable align xyz positioned ~0.5 ~0.5 ~0.5 run function zzz:copycat/mine/commit

execute positioned ^ ^ ^0.1 unless entity @s[distance=5..] run function zzz:copycat/mine/loop