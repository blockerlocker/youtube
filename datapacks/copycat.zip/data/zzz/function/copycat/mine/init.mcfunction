function zzz:copycat/mine/reset

execute at @s as @e[type=!player,nbt={Brain:{}},distance=..128,sort=nearest] positioned as @s anchored eyes positioned ^ ^ ^ run function zzz:copycat/mine/loop