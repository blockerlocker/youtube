execute as @e[nbt={Brain:{}}] run attribute @s step_height modifier remove copycat:step

# Make all mobs near player jump
execute as @a if predicate {condition:entity_properties,entity:this,predicate:{type_specific:{type:player,input:{jump:true}}}} at @s as @e[type=!player,nbt={Brain:{}},distance=..128] if predicate {condition:entity_properties,entity:this,predicate:{flags:{is_on_ground:true}}} run data modify entity @s Motion[1] set value 0.4

# Detect if player is hitting WASD keys
execute as @a unless predicate {condition:entity_properties,entity:this,predicate:{type_specific:{type:player,input:{forward:false,backward:false,left:false,right:false}}}} at @s run function zzz:copycat/player_walk

# Detect if player mined block
execute as @a if predicate copycat:mined_block run function zzz:copycat/mine/init