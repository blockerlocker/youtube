scoreboard players reset @s mobs_keep_me_alive_respawn
execute unless entity @e[type=#mobs_keep_me_alive:respawn_mobs,distance=..6] run tag @s add mobs_keep_me_alive_respawn