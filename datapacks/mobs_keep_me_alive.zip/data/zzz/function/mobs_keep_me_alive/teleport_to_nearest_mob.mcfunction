# Respawn if mob within 24 blocks that can see sky
execute as @e[type=#mobs_keep_me_alive:respawn_mobs,distance=..24] at @s if predicate {condition:"minecraft:location_check",predicate:{can_see_sky:1b}} run tag @s add mobs_keep_me_alive_sky
execute store result storage mobs_keep_me_alive:temp all.respawn int 1 run tp @s @n[type=#mobs_keep_me_alive:respawn_mobs,tag=mobs_keep_me_alive_sky]
tag @e[tag=mobs_keep_me_alive_sky] remove mobs_keep_me_alive_sky
execute if data storage mobs_keep_me_alive:temp all{respawn:1} run tag @s remove mobs_keep_me_alive_respawn
execute if data storage mobs_keep_me_alive:temp all{respawn:1} run return run data remove storage mobs_keep_me_alive:temp all

# Respawn if mob within 24 blocks that is on "motion blocking no leaves"
execute as @e[type=#mobs_keep_me_alive:respawn_mobs,distance=..24] at @s positioned over motion_blocking_no_leaves if entity @s[distance=..1] run tag @s add mobs_keep_me_alive_motion_block
execute store result storage mobs_keep_me_alive:temp all.respawn int 1 run tp @s @n[type=#mobs_keep_me_alive:respawn_mobs,tag=mobs_keep_me_alive_motion_block]
tag @e[tag=mobs_keep_me_alive_motion_block] remove mobs_keep_me_alive_motion_block
execute if data storage mobs_keep_me_alive:temp all{respawn:1} run tag @s remove mobs_keep_me_alive_respawn
execute if data storage mobs_keep_me_alive:temp all{respawn:1} run return run data remove storage mobs_keep_me_alive:temp all

# Respawn if mob within 24 blocks is above sea level
execute as @e[type=#mobs_keep_me_alive:respawn_mobs,distance=..24] at @s at @s if entity @s[y=60,dy=1000] run tag @s add mobs_keep_me_alive_above_sea_level
execute store result storage mobs_keep_me_alive:temp all.respawn int 1 run tp @s @n[type=#mobs_keep_me_alive:respawn_mobs,tag=mobs_keep_me_alive_above_sea_level]
tag @e[tag=mobs_keep_me_alive_above_sea_level] remove mobs_keep_me_alive_above_sea_level
execute if data storage mobs_keep_me_alive:temp all{respawn:1} run tag @s remove mobs_keep_me_alive_respawn
execute if data storage mobs_keep_me_alive:temp all{respawn:1} run return run data remove storage mobs_keep_me_alive:temp all

# Respawn if mob within 48 blocks that can see sky
execute as @e[type=#mobs_keep_me_alive:respawn_mobs,distance=..48] at @s if predicate {condition:"minecraft:location_check",predicate:{can_see_sky:1b}} run tag @s add mobs_keep_me_alive_sky
execute store result storage mobs_keep_me_alive:temp all.respawn int 1 run tp @s @n[type=#mobs_keep_me_alive:respawn_mobs,tag=mobs_keep_me_alive_sky]
tag @e[tag=mobs_keep_me_alive_sky] remove mobs_keep_me_alive_sky
execute if data storage mobs_keep_me_alive:temp all{respawn:1} run tag @s remove mobs_keep_me_alive_respawn
execute if data storage mobs_keep_me_alive:temp all{respawn:1} run return run data remove storage mobs_keep_me_alive:temp all

# Respawn if mob within 48 blocks that is on "motion blocking no leaves"
execute as @e[type=#mobs_keep_me_alive:respawn_mobs,distance=..48] at @s positioned over motion_blocking_no_leaves if entity @s[distance=..1] run tag @s add mobs_keep_me_alive_motion_block
execute store result storage mobs_keep_me_alive:temp all.respawn int 1 run tp @s @n[type=#mobs_keep_me_alive:respawn_mobs,tag=mobs_keep_me_alive_motion_block]
tag @e[tag=mobs_keep_me_alive_motion_block] remove mobs_keep_me_alive_motion_block
execute if data storage mobs_keep_me_alive:temp all{respawn:1} run tag @s remove mobs_keep_me_alive_respawn
execute if data storage mobs_keep_me_alive:temp all{respawn:1} run return run data remove storage mobs_keep_me_alive:temp all

# Respawn if mob within 48 blocks is above sea level
execute as @e[type=#mobs_keep_me_alive:respawn_mobs,distance=..48] at @s at @s if entity @s[y=60,dy=1000] run tag @s add mobs_keep_me_alive_above_sea_level
execute store result storage mobs_keep_me_alive:temp all.respawn int 1 run tp @s @n[type=#mobs_keep_me_alive:respawn_mobs,tag=mobs_keep_me_alive_above_sea_level]
tag @e[tag=mobs_keep_me_alive_above_sea_level] remove mobs_keep_me_alive_above_sea_level
execute if data storage mobs_keep_me_alive:temp all{respawn:1} run tag @s remove mobs_keep_me_alive_respawn
execute if data storage mobs_keep_me_alive:temp all{respawn:1} run return run data remove storage mobs_keep_me_alive:temp all

# Respawn if any loaded mob that can see sky
execute as @e[type=#mobs_keep_me_alive:respawn_mobs] at @s if predicate {condition:"minecraft:location_check",predicate:{can_see_sky:1b}} run tag @s add mobs_keep_me_alive_sky
execute store result storage mobs_keep_me_alive:temp all.respawn int 1 run tp @s @n[type=#mobs_keep_me_alive:respawn_mobs,tag=mobs_keep_me_alive_sky]
tag @e[tag=mobs_keep_me_alive_sky] remove mobs_keep_me_alive_sky
execute if data storage mobs_keep_me_alive:temp all{respawn:1} run tag @s remove mobs_keep_me_alive_respawn
execute if data storage mobs_keep_me_alive:temp all{respawn:1} run return run data remove storage mobs_keep_me_alive:temp all

# Respawn if any loaded mob that is on "motion blocking no leaves"
execute as @e[type=#mobs_keep_me_alive:respawn_mobs] at @s positioned over motion_blocking_no_leaves if entity @s[distance=..1] run tag @s add mobs_keep_me_alive_motion_block
execute store result storage mobs_keep_me_alive:temp all.respawn int 1 run tp @s @n[type=#mobs_keep_me_alive:respawn_mobs,tag=mobs_keep_me_alive_motion_block]
tag @e[tag=mobs_keep_me_alive_motion_block] remove mobs_keep_me_alive_motion_block
execute if data storage mobs_keep_me_alive:temp all{respawn:1} run tag @s remove mobs_keep_me_alive_respawn
execute if data storage mobs_keep_me_alive:temp all{respawn:1} run return run data remove storage mobs_keep_me_alive:temp all

# Respawn if any loaded mob is above sea level
execute as @e[type=#mobs_keep_me_alive:respawn_mobs] at @s at @s if entity @s[y=60,dy=1000] run tag @s add mobs_keep_me_alive_above_sea_level
execute store result storage mobs_keep_me_alive:temp all.respawn int 1 run tp @s @n[type=#mobs_keep_me_alive:respawn_mobs,tag=mobs_keep_me_alive_above_sea_level]
tag @e[tag=mobs_keep_me_alive_above_sea_level] remove mobs_keep_me_alive_above_sea_level
execute if data storage mobs_keep_me_alive:temp all{respawn:1} run tag @s remove mobs_keep_me_alive_respawn
execute if data storage mobs_keep_me_alive:temp all{respawn:1} run return run data remove storage mobs_keep_me_alive:temp all

# Respawn at any loaded mob within 24 blocks
execute store result storage mobs_keep_me_alive:temp all.respawn int 1 run tp @s @n[type=#mobs_keep_me_alive:respawn_mobs,distance=..24]
execute if data storage mobs_keep_me_alive:temp all{respawn:1} run tag @s remove mobs_keep_me_alive_respawn
execute if data storage mobs_keep_me_alive:temp all{respawn:1} run return run data remove storage mobs_keep_me_alive:temp all

# Respawn at any loaded mob
execute store result storage mobs_keep_me_alive:temp all.respawn int 1 run tp @s @n[type=#mobs_keep_me_alive:respawn_mobs]
execute if data storage mobs_keep_me_alive:temp all{respawn:1} run tag @s remove mobs_keep_me_alive_respawn
execute if data storage mobs_keep_me_alive:temp all{respawn:1} run return run data remove storage mobs_keep_me_alive:temp all