execute as @a if predicate {condition:entity_properties,entity:this,predicate:{periodic_tick:15}} at @s unless entity @e[type=#mobs_keep_me_alive:respawn_mobs,distance=..3] run damage @s 2 dry_out

execute as @e[type=player,scores={mobs_keep_me_alive_respawn=1..}] at @s run function zzz:mobs_keep_me_alive/respawned

execute as @e[type=player,tag=mobs_keep_me_alive_respawn] at @s run function zzz:mobs_keep_me_alive/teleport_to_nearest_mob
