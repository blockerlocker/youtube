execute store success storage motion_vector:temp loaded.a int 1 run forceload query 1 1
execute store success storage motion_vector:temp loaded.b int 1 run forceload query 1 -1
execute store success storage motion_vector:temp loaded.c int 1 run forceload query -1 1
execute store success storage motion_vector:temp loaded.d int 1 run forceload query -1 -1
execute if data storage motion_vector:temp loaded{a:0} run forceload add 1 1 1 1
execute if data storage motion_vector:temp loaded{b:0} run forceload add 1 -1 1 -1
execute if data storage motion_vector:temp loaded{c:0} run forceload add -1 1 -1 1
execute if data storage motion_vector:temp loaded{d:0} run forceload add -1 -1 -1 -1

execute run summon marker ~ ~ ~ {Tags:[motion_vector_motion]}
execute run data modify storage motion_vector:temp motion set from entity @n[type=marker,tag=motion_vector_motion] Pos
kill @e[type=marker,tag=motion_vector_motion]

execute if data storage motion_vector:temp loaded{a:0} run forceload remove 1 1 1 1
execute if data storage motion_vector:temp loaded{b:0} run forceload remove 1 -1 1 -1
execute if data storage motion_vector:temp loaded{c:0} run forceload remove -1 1 -1 1
execute if data storage motion_vector:temp loaded{d:0} run forceload remove -1 -1 -1 -1
data remove storage motion_vector:temp loaded