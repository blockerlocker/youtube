function gu:convert with entity @s
function zzz:player_splitting/player_team/create with storage gu:main