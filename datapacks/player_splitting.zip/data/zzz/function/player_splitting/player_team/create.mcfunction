$team add player_splitting_$(out)
$team join player_splitting_$(out)