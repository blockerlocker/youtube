$data modify entity @s profile set value $(name)
$data modify entity @s CustomName set value $(name)
$team join player_splitting_$(uuid)

tag @s remove player_splitting_new