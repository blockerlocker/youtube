scoreboard players reset @s player_splitting.deaths

tag @s add player_splitting_summon

summon mannequin ~ ~ ~ {Tags:[player_splitting_mannequin,player_splitting_new],hide_description:true,CustomNameVisible:true}

summon minecraft:text_display ~ ~ ~ {Tags:[player_splitting_name_grab],text:{selector:"@p[tag=player_splitting_summon]"}}
data modify storage player_splitting:temp all.name set from entity @n[type=text_display,tag=player_splitting_name_grab] text.hover_event.name
kill @n[type=text_display,tag=player_splitting_name_grab]

function gu:convert with entity @s
data modify storage player_splitting:temp all.uuid set from storage gu:main out

execute as @n[type=mannequin,tag=player_splitting_new] run function zzz:player_splitting/split/set_data with storage player_splitting:temp all

tag @s remove player_splitting_summon


playsound entity.slime.death player @a ~ ~ ~ 1 1
particle item_slime ~ ~1 ~ 0.25 0.5 0.25 1 20