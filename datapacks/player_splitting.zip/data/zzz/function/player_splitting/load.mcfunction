gamerule immediate_respawn true
gamerule keep_inventory true

scoreboard objectives add player_splitting.deaths deathCount