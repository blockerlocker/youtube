# Rotation
$execute as @e[type=mannequin,tag=player_splitting_mannequin,team=player_splitting_$(uuid)] run rotate @s ~ ~

# Crouching
$execute if predicate {condition:entity_properties,entity:this,predicate:{flags:{is_sneaking:true}}} as @e[type=mannequin,tag=player_splitting_mannequin,team=player_splitting_$(uuid)] run function zzz:player_splitting/control/crouching
$execute unless predicate {condition:entity_properties,entity:this,predicate:{flags:{is_sneaking:true}}} as @e[type=mannequin,tag=player_splitting_mannequin,team=player_splitting_$(uuid)] run function zzz:player_splitting/control/standing