attribute @s step_height base reset
data modify entity @s pose set value crouching