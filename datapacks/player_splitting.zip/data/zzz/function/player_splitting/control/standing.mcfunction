attribute @s step_height base set 1.2
data modify entity @s pose set value standing