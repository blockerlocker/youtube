$execute unless entity $(target) run data remove entity @s data.target

$execute at $(target) if entity @s[distance=0.001..6] run rotate @s facing entity $(target)
$execute if predicate {condition:entity_properties,entity:this,predicate:{periodic_tick:10}} at $(target) if entity @s[distance=0.001..6] run damage $(target) 1 player_attack by @s
$execute if predicate {condition:entity_properties,entity:this,predicate:{periodic_tick:10}} at $(target) if entity @s[distance=0.001..6] run swing
