function gu:convert with entity @s
data modify storage player_splitting:temp all.target set from storage gu:main out

execute on attacker run function gu:convert with entity @s
data modify storage player_splitting:temp all.player set from storage gu:main out

function zzz:player_splitting/control/attack/mark with storage player_splitting:temp all