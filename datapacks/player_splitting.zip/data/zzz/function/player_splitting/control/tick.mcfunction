function gu:convert with entity @s
data modify storage player_splitting:temp all.uuid set from storage gu:main out

# With UUID
function zzz:player_splitting/control/with_uuid with storage player_splitting:temp all

# Player Jump
execute if predicate {condition:entity_properties,entity:this,predicate:{type_specific:{type:player,input:{jump:true}}}} run function zzz:player_splitting/control/jump with storage player_splitting:temp all

# Player Walk
execute unless predicate {condition:entity_properties,entity:this,predicate:{type_specific:{type:player,input:{forward:false,backward:false,left:false,right:false}}}} run function zzz:player_splitting/control/walk

# Player Mine
execute if predicate bldp:mined_block run function zzz:player_splitting/control/mine/init with storage player_splitting:temp all