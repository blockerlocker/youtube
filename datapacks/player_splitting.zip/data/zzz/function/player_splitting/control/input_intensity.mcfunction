execute if predicate {condition:entity_properties,entity:this,predicate:{flags:{is_sneaking:false}}} positioned 0.0 0.0 0.0 positioned ^ ^ ^0.225 run function zzz:get_motion_vector
execute if predicate {condition:entity_properties,entity:this,predicate:{flags:{is_sneaking:true}}} positioned 0.0 0.0 0.0 positioned ^ ^ ^0.066 run function zzz:get_motion_vector

$execute as @e[type=mannequin,tag=player_splitting_mannequin,team=player_splitting_$(uuid)] run function zzz:player_splitting/control/apply_motion

data remove storage motion_vector:temp motion