execute unless block ~ ~ ~ #bldp:fluid run return run execute unless block ~ ~ ~ #bldp:unbreakable align xyz positioned ~0.5 ~0.5 ~0.5 run function zzz:player_splitting/control/mine/commit

execute positioned ^ ^ ^0.1 unless entity @s[distance=5..] run function zzz:player_splitting/control/mine/loop