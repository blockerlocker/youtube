function zzz:bldp/mined_block/reset

$execute as @e[type=mannequin,tag=player_splitting_mannequin,team=player_splitting_$(uuid)] positioned as @s anchored eyes positioned ^ ^ ^ run function zzz:player_splitting/control/mine/loop