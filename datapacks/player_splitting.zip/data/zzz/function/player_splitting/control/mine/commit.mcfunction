execute unless block ~ ~ ~ #mineable/pickaxe run loot spawn ~ ~ ~ mine ~ ~ ~ air
swing

summon item_display ~ ~ ~ {Tags:[bldp_blockstate]}
loot replace entity @n[type=item_display,tag=bldp_blockstate] contents loot blockstate:get
function zzz:player_splitting/control/mine/particle with entity @n[type=item_display,tag=bldp_blockstate] item.components."minecraft:custom_data"
kill @n[type=item_display,tag=bldp_blockstate]

setblock ~ ~ ~ air replace
