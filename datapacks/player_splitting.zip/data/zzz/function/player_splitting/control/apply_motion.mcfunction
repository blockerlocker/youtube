data modify entity @s Motion[0] set from storage motion_vector:temp motion[0]
data modify entity @s Motion[2] set from storage motion_vector:temp motion[2]