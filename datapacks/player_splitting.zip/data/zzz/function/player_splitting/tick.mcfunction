# Set respawn to player's location
execute as @a at @s run spawnpoint @s ~ ~ ~ ~ ~

# Player tick
execute as @a at @s run function zzz:player_splitting/control/tick

# Split player on death
execute as @a[scores={player_splitting.deaths=1..}] at @s run function zzz:player_splitting/split/init

# Entity Hurt
execute as @e[nbt={Brain:{},HurtTime:9s}] at @s on attacker if entity @s[type=player] as @n[nbt={Brain:{},HurtTime:9s}] run function zzz:player_splitting/control/attack/init

# Mannequin Attack
execute as @e[tag=player_splitting_mannequin] if data entity @s data.target at @s run function zzz:player_splitting/control/attack/commit with entity @s data