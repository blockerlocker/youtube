advancement revoke @s only craftsplode:craft_any

summon tnt