# Run the player ticking function for every player, at their eye position for use in iris raycasting
execute as @a at @s anchored eyes positioned ^ ^ ^ run function zzz:minegrow/player_tick