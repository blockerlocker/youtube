# Start the mining function when the player mines a block
execute if predicate bldp:mined_block run function zzz:minegrow/mine/main

# Display current mining size
function zzz:minegrow/display/main

# Mark the current block the player is looking at to be used in the next tick if the player mines a block
function iris:get_target

# Reset mining size on death
scoreboard players reset @s[scores={minegrow_death=1..}] minegrow
scoreboard players reset @s[scores={minegrow_death=1..}] minegrow_death