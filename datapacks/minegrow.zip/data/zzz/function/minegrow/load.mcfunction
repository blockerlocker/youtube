scoreboard objectives add minegrow dummy
scoreboard objectives add minegrow_death deathCount