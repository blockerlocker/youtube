$execute positioned ~-$(offset) 319 ~-$(offset) run fill ~ ~ ~ ~$(size) ~-$(size) ~$(size) air replace #minegrow:mineable_fist destroy

$execute if items entity @s weapon.mainhand #minegrow:mineable_wood positioned ~-$(offset) 319 ~-$(offset) run fill ~ ~ ~ ~$(size) ~-$(size) ~$(size) air replace #minegrow:needs_wood_tool destroy
$execute if items entity @s weapon.mainhand #minegrow:mineable_stone positioned ~-$(offset) 319 ~-$(offset) run fill ~ ~ ~ ~$(size) ~-$(size) ~$(size) air replace #minecraft:needs_stone_tool destroy
$execute if items entity @s weapon.mainhand #minegrow:mineable_iron positioned ~-$(offset) 319 ~-$(offset) run fill ~ ~ ~ ~$(size) ~-$(size) ~$(size) air replace #minecraft:needs_iron_tool destroy
$execute if items entity @s weapon.mainhand #minegrow:mineable_diamond positioned ~-$(offset) 319 ~-$(offset) run fill ~ ~ ~ ~$(size) ~-$(size) ~$(size) air replace #minecraft:needs_diamond_tool destroy
