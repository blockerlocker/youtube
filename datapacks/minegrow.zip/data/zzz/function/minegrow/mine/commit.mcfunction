$execute if predicate {condition:"minecraft:location_check",offsetY:-$(offset),predicate:{position:{y:{max:-64}}}} run return run function zzz:minegrow/mine/commit_bottom_of_world with storage minegrow:temp all
$execute if predicate {condition:"minecraft:location_check",offsetY:$(offset),predicate:{position:{y:{min:319}}}} run return run function zzz:minegrow/mine/commit_top_of_world with storage minegrow:temp all

$execute positioned ~-$(offset) ~-$(offset) ~-$(offset) run fill ~ ~ ~ ~$(size) ~$(size) ~$(size) air replace #minegrow:mineable_fist destroy

$execute if items entity @s weapon.mainhand #minegrow:mineable_wood positioned ~-$(offset) ~-$(offset) ~-$(offset) run fill ~ ~ ~ ~$(size) ~$(size) ~$(size) air replace #minegrow:needs_wood_tool destroy
$execute if items entity @s weapon.mainhand #minegrow:mineable_stone positioned ~-$(offset) ~-$(offset) ~-$(offset) run fill ~ ~ ~ ~$(size) ~$(size) ~$(size) air replace #minecraft:needs_stone_tool destroy
$execute if items entity @s weapon.mainhand #minegrow:mineable_iron positioned ~-$(offset) ~-$(offset) ~-$(offset) run fill ~ ~ ~ ~$(size) ~$(size) ~$(size) air replace #minecraft:needs_iron_tool destroy
$execute if items entity @s weapon.mainhand #minegrow:mineable_diamond positioned ~-$(offset) ~-$(offset) ~-$(offset) run fill ~ ~ ~ ~$(size) ~$(size) ~$(size) air replace #minecraft:needs_diamond_tool destroy
