# Reset the scoreboards used to detect mining
function bldp:mined_block/reset

# If the player doesn't have a 'minegrow' score, end the function and give them one
execute unless score @s minegrow matches 1.. run return run scoreboard players set @s minegrow 1

# Store size and offset (half of size) to data storage for use in function macros
execute store result storage minegrow:temp all.offset float 0.5 run scoreboard players get @s minegrow
execute store result storage minegrow:temp all.size int 1 run scoreboard players get @s minegrow

# Run the function the destroys blocks with the previously stored data as the macro source
execute at @n[type=marker,tag=iris.targeted_block] run function zzz:minegrow/mine/commit with storage minegrow:temp all

# Increase grow size
scoreboard players add @s minegrow 1