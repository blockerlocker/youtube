scoreboard players operation #mine_width minegrow = @s minegrow

scoreboard players add #mine_width minegrow 1

scoreboard players operation #mine_size minegrow = #mine_width minegrow

scoreboard players operation #mine_size minegrow *= #mine_width minegrow
scoreboard players operation #mine_size minegrow *= #mine_width minegrow

title @s actionbar [{text:"Next mine: ",color:aqua},{score:{name:"#mine_size",objective:minegrow},color:gold},{text:" blocks",color:gold}]